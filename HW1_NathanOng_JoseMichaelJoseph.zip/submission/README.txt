First ensure that your Java version is at least 1.8

To compile, use the command line to go into the src folder and type:

javac window/MainWindow.java

Then to run:

java window.MainWindow
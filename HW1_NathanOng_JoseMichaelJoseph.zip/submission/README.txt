First ensure that your Java version is at least 1.8

To compile, use the command line to go into the src folder and type:

javac window/MainWindow.java

Then to run:

java window.MainWindow

---

The online runnable jar version can be found at http://mips.lrdc.pitt.edu/cs2610-fall14/HW1-NathanOng_JoseMichaelJoseph
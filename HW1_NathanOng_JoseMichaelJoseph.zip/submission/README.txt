First ensure that your Java version is at least 1.8

To compile, use the command line to go into the src folder and type:

javac window/MainWindow.java

Then to run:

java window.MainWindow

---

The online runnable jar version can be found at http://mips.lrdc.pitt.edu/cs2610-fall14/HW1-NathanOng_JoseMichaelJoseph

---

We'd like to note that the submission you see here is not necessarily the same as what you would see in the demo video.  This is because we had to make a couple of bug fixes, and also we did not show the Levenshtein window, which you can get to by a menu.

Please send us an email at nro5@pitt.edu and joj33@pitt.edu if you have any questions.